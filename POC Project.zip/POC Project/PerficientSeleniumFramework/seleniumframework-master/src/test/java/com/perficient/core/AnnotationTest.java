package com.perficient.core;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Properties;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.testng.IAnnotationTransformer;
import org.testng.annotations.ITestAnnotation;

public class AnnotationTest implements IAnnotationTransformer {
	
	public static ArrayList<String> excludedTestCaseNames;
	public static String inputType; 
	
	public void transform(ITestAnnotation annotation, Class testClass, Constructor testConstructor, Method testMethod) {
		//Based on the To Be Executed flag, we continue the Test Method execution
		if(inputType.equalsIgnoreCase("excel")) {
			if (excludedTestCaseNames.contains(testMethod.getName()))
				annotation.setEnabled(false);
		}
	}
	
	public AnnotationTest() { 
		excludedTestCaseNames = new ArrayList<String>();
		
		try {
			File configFile = new File("user_config.properties");
			FileReader reader = new FileReader(configFile);
			Properties property = new Properties();
			// load the properties file:
			property.load(reader);
			inputType = property.getProperty("whichinputfiletouse");
			
			if(inputType.equalsIgnoreCase("excel")) {
				FileInputStream fs = new FileInputStream(property.getProperty("inputexcelpath"));
				HSSFWorkbook wb = new HSSFWorkbook(fs);
				HSSFSheet sheet = wb.getSheet("TestData");
	
				for(int i = 0; i <= sheet.getLastRowNum(); i++) {
	
					if(sheet.getRow(i).getCell(2,Row.CREATE_NULL_AS_BLANK).getStringCellValue().equals("N")) {
						excludedTestCaseNames.add(sheet.getRow(i).getCell(0).getStringCellValue());
					}
				}
				
				fs.close();
			}

		} catch(Exception e) {
			e.printStackTrace();
		}
	}

}