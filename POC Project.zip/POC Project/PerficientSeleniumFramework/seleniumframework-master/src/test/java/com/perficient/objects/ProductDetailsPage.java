package com.perficient.objects;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.perficient.core.TestDriver;

public class ProductDetailsPage extends TestDriver {
	WebDriver driver;
	
    public ProductDetailsPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    
    
    //Defining all the required Web
    @FindBy(xpath="//input[@id='pinCodeCheckInput']")
    WebElement pincode_Input;
    
    @FindBy(xpath="//button[@class='pin-code-info__submit']")
    WebElement pincode_Submit;
    
    @FindBy(xpath="//div[@class='pin-code-info__content']")
    WebElement pincode_Error;
    
    @FindBy(xpath="//button[@class='add-cart-section__btn add-cart-section__submit add-cart-section__submit--main']")
    WebElement buy_Button;
    
    @FindBy(xpath="//button[contains(text(),'Change Pincode')]")
    WebElement changePincode_Button;
    
    public void enterPincode(CharSequence user) throws Exception {
    	scrollInToView(pincode_Input);
    	click(pincode_Input);
    	pincode_Input.sendKeys(user);
    	waitFor(1);
    }
    
    
    //Entering the Pincode with both Flows
    public void pincodeSubmit() throws Exception {
    	report("PASS", String.format("Pincode added "), false);
    	
    	click(pincode_Submit);
    	
		try {
		if(pincode_Error.isDisplayed()) {
			report("PASS", String.format(pincode_Error.getText()), false);
			System.out.println(pincode_Error.getText());
			waitFor(2);
			click(changePincode_Button);
		}
		}
		catch (NoSuchElementException e) {
			report("INFO", String.format("User has entered valid Pincode"), false);
			System.out.println("User has entered valid Pincode");
		}
		waitFor(2);
    }
    
    // Redirecting to Checkout Page
    public void buyNow() throws Exception {
    	
    	report("PASS", String.format("Moved to checkout page "), false);
    	scrollInToView(buy_Button);
    	waitUntilElementClickable(buy_Button);
		click(buy_Button);
    }
    
}
