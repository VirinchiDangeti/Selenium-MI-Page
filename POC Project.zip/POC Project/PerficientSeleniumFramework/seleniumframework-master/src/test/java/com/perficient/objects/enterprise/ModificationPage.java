package com.perficient.objects.enterprise;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.perficient.core.TestDriver;

public class ModificationPage extends TestDriver{
	WebDriver driver;
	
    public ModificationPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    
    @FindBy(xpath="//input[@id='phoneNumber']")
	WebElement modifyNumber_input;
    
    @FindBy(xpath="//input[@id='email']")
	WebElement modifyEmail_input;
    
    @FindBy(xpath="//button[@class='cta cta--primary cta--large cta--noMargin' and @aria-label='Continue to Review']")
	WebElement continueReview_button;
    
    @FindBy(xpath="//h6[contains(text(),'Extras')]")
	WebElement extrasPage_button;
    
    @FindBy(xpath="//button[@class='cta cta--secondary cta--small cta--icons cta--noMargin cta--noWrap' and @aria-label='Add']")
    WebElement addExtras_button;
    
    @FindBy(xpath="//button[@class='cta cta--primary cta--extra-large cta--noMargin' and @aria-label='Update Reservation']")
    WebElement updateReservation_button;
    
    
    public void ModifyDetails() throws Exception{
    	modifyEmail_input.sendKeys("virinchi@gmail.com");
    	waitFor(10);
    	report("Pass", String.format("Modifying the Email Address"), true);
    	extrasPage_button.click();
    	waitFor(10);
    	addExtras_button.click();
    	waitFor(10);
    	report("Pass", String.format("Additional extra is added"), true);
    	continueReview_button.click();
    	waitFor(10);
    	updateReservation_button.click();
    	waitFor(10);
    }
}
