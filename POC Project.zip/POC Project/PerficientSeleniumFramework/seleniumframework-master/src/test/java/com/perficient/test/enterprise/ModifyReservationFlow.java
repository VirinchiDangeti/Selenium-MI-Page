package com.perficient.test.enterprise;

import org.testng.annotations.Test;

import com.perficient.core.TestDriver;
import com.perficient.objects.enterprise.ConfirmationPage;
import com.perficient.objects.enterprise.DetailsPage;
import com.perficient.objects.enterprise.HomePageEnterprise;
import com.perficient.objects.enterprise.ModificationPage;

public class ModifyReservationFlow extends TestDriver {
	@Test (dataProvider="data-provider", dataProviderClass=TestDriver.class)
	public void ModificationFlow() throws Exception{

		open("https://enterprise-use-aem.enterprise.com/en/home.html");
		waitFor(10);
		
		// Defining the Home Page
		HomePageEnterprise home = new HomePageEnterprise(driver);
		home.happyFlow();
		
		// Defining the Details Page
		DetailsPage details = new DetailsPage(driver);
		details.customerDetails();
		
		// Defining the Confirmation Page
		ConfirmationPage confirmation =new ConfirmationPage(driver);
		confirmation.modificationFlow();
		waitFor(10);
		report("PASS", String.format("Reservation Modification"), true);
		
		//Defining the Modification Page
		ModificationPage modification = new ModificationPage(driver);
		modification.ModifyDetails();
		waitFor(10);
		report("PASS", String.format("Reservation Modified"), true);

	}
}
