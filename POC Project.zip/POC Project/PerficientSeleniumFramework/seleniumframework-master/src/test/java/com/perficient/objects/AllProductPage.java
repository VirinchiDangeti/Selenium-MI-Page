package com.perficient.objects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.perficient.core.TestDriver;

public class AllProductPage extends TestDriver {
	WebDriver driver;
	
    public AllProductPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    
    //Defining all the required webelements.
    @FindBy(xpath="//span[text()='All Redmi Phones']")
    WebElement redmiPhones_Button;
    
    @FindBy(xpath="//span[text()='Redmi Series']")
    WebElement redmiHeader;
    
  
    //Scroll to Redmi Phones Button and Click.
    public void redmiPhonePage() throws Exception {
    	report("Pass", String.format("Clicking on Redmi Phones section "), false);
    	waitFor(4);
    	scrollInToView(redmiHeader);
    	waitFor(3);
    	click(redmiPhones_Button);
    	waitUntilUrlContains("https://www.mi.com/in/product-list/redmi/");
    }
}
