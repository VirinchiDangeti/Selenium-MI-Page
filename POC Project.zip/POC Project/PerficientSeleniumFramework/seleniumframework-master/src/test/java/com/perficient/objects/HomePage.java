package com.perficient.objects;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


import java.util.List;
import com.perficient.core.TestDriver;

public class HomePage extends TestDriver {
		WebDriver driver;
		
	    public HomePage(WebDriver driver) {
	        this.driver = driver;
	        PageFactory.initElements(driver, this);
	    }
	    
	@FindBy(xpath="//i[@class='micon micon-account shortcut__icon']")
	WebElement account_Img;
	
	@FindBy(xpath="//button[text()='Allow']")
	WebElement accept_Alert;
	
	@FindBy(xpath="//a[@aria-label='Phone']")
	WebElement phone_Link;
	
	@FindBy(xpath="//a[contains(text(),'Mi Authorized Store')]")
	WebElement authorizedStore_link;
	
	@FindBy(xpath="//div[@class='picker-title J_picker-title']//child::span[@class='J_span J_state-span']")
	WebElement stateSelect_Dropdown;
	
	@FindBy(xpath="//div[@class='picker-title J_picker-title']//child::span[@class='J_span J_city-span']")
	WebElement citySelect_Dropdown;
	
	@FindBy(xpath="//li[@service-data='ANDHRA PRADESH']")
	WebElement stateSelection;
	
	@FindBy(xpath="//li[@service-data='All cities']")
	WebElement citySelection;
	
	@FindBy(xpath="//ul[@class='table J_table clearfix']//li")
	WebElement storeSelection;
	
	@FindBy(xpath="//i[@class='micon micon-delete cart__font--muted cart__item-delete']")
	WebElement emptyCart_Button;
	
	@FindBy(xpath="//i[@class='micon micon-shopping-cart shortcut__icon']")
	WebElement cart_Icon;
	
	@FindBy(xpath="//div[@class='cart__item-link']")
	WebElement cartItem;

	
	
	//Function to enter the account login
	public void openSignin() throws Exception {
		report("PASS", String.format(" Navigating to Login "), false);
		waitUntilElementClickable(accept_Alert);
		click(accept_Alert);
		waitFor(2);
		waitUntilElementClickable(account_Img);
		click(account_Img);
		waitFor(2);
	}
	
	
	//Function to redirect to Phone Page 	
	public void phonePage() {
		report("PASS", String.format(" Redirecting to phone page "), false);
		click(phone_Link);
	}
	
	
	
	//To print the options available in the dropdown after Signing In
	public void accountSignOut() {
		report("Pass", String.format(" Printing the options availabe in dropdown after signing in "), false);
		
		Actions actions = new Actions(driver);
	    actions.moveToElement(account_Img).perform();
	    WebElement SignOut = driver.findElement(By.xpath("//a[text()='Sign Out']"));
	    actions.moveToElement(SignOut);
	    actions.click().build().perform();
	    actions.moveToElement(account_Img).perform();
	    List<WebElement> DropDownAfterSignIn  = driver.findElements(By.xpath("//ul[@class='view-account__list']//li"));
	    System.out.println("DropDown after user sign in:");
	    for (WebElement i : DropDownAfterSignIn) {
	         System.out.println(i.getText());
	     }
	}
	
	
	//To print the options available in the dropdown after Signing Out
	public void signinDropdown() {
		report("PASS", String.format("Printing the options availabe in dropdown after signing out "), false);
		waitFor(4);
		Actions actions = new Actions(driver);
		actions.moveToElement(account_Img).perform();
		List<WebElement> DropDownAfterSignOut  = driver.findElements(By.xpath("//ul[@class='view-account__list']//li"));
		System.out.println("DropDown after user sign out:");
		for (WebElement i : DropDownAfterSignOut) {
		     System.out.println(i.getText());
		}
	}
	
	//To clear the cart
	public void clearCart() {
		report("PASS", String.format("Clearing the items in cart"), false);
		Actions actions = new Actions(driver);
		actions.moveToElement(cart_Icon).perform();
		
		try {
			if(cartItem.isDisplayed()) {
				actions.moveToElement(cartItem).perform();
				if(emptyCart_Button.isDisplayed()) {
					click(emptyCart_Button);
					report("INFO", String.format("The Cart is cleared"), false);
				}
			}

			}
			catch (NoSuchElementException e) {
				report("INFO", String.format("Cart is empty"), false);
			}
	}
	
	//To accesses the Authorized store link from footer
	public void authorizedStoreLink() throws Exception {
		report("Pass", String.format("To open authorized store window "), false);
		String mainWindow = driver.getWindowHandle();
		waitFor(2);
		scrollInToView(authorizedStore_link);
		waitFor(1);
		click(authorizedStore_link);
		waitFor(2);
		
		driver.switchTo().window(mainWindow);
		waitFor(2);
		// Switch to the new window
		for (String windowHandle : driver.getWindowHandles()) {
		    if (!windowHandle.equals(mainWindow)) {
		        driver.switchTo().window(windowHandle);
		        break;
		    }
		}
		
		click(stateSelect_Dropdown);
		click(stateSelection);
		waitFor(1);
		
		click(citySelect_Dropdown);
		click(citySelection);
		
		scrollInToView(storeSelection);
		
		System.out.println(storeSelection.getText());
		report("INFO", String.format(storeSelection.getText()), false);
		waitFor(2);
		driver.close();
		driver.switchTo().window(mainWindow);
		scrollToTop();
		waitFor(4);
	}
}
