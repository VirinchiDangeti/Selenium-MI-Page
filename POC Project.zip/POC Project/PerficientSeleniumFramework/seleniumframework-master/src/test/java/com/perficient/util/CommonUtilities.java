package com.perficient.util;

import java.io.File;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Random;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.perficient.core.TestDriver;
import com.relevantcodes.extentreports.LogStatus;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CommonUtilities {

	public static Actions builder = null;
	public static JavascriptExecutor js = null;

	// Get the screenshot
	public String getScreenshot(WebDriver driver, String Status) {
		File srcFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		String imageName = new SimpleDateFormat("'SS_'yyyyMMdd_HHmmss'_" + TestDriver.data.get("TC_Name") + "_"
				+ Status + ".png'").format(new Date());
		File destFile = new File(TestDriver.props.getProperty("ReportFolder") + imageName);
		
		try {
			FileUtils.copyFile(srcFile, destFile);
		} catch(Exception e) { }
		
		return imageName;
	}

	// Log the test step report to the corresponding test case
	public void report(String Status, String Description, boolean isScreenshotNeeded) {
		String screenshotPath = ""; 
		
		if (isScreenshotNeeded) {
			screenshotPath = getScreenshot(TestDriver.driver, Status.toUpperCase());
			Description = Description + TestDriver.test.addScreenCapture(screenshotPath);
		}
		
		switch (Status.toUpperCase()) {
		case "PASS":
			TestDriver.test.log(LogStatus.PASS, Description);
			break;
		case "FAIL":
			TestDriver.test.log(LogStatus.FAIL, Description);
			Assert.fail(Description);
			break;
		case "WARNING":
			TestDriver.test.log(LogStatus.WARNING, Description);
			break;
		case "INFO":
			TestDriver.test.log(LogStatus.INFO, Description);
			break;
		case "ERROR":
			TestDriver.test.log(LogStatus.ERROR, Description);
			break;
		default:
			TestDriver.test.log(LogStatus.UNKNOWN, Description);
			break;
		}
	}

	// Open a URL in the driver's browser
	public void open(String strURL) throws Exception {
		TestDriver.driver.get(strURL);
		report("INFO", String.format("Navigated to page - %s", strURL), false);
	}

	// Wait for parameterized amount of seconds
	public void waitFor(long waitSeconds) {
		try {
			Thread.sleep(waitSeconds * 1000);
		} catch (Exception e) { }
	}

	// Switch to the second window
	public void switchToTab(int n) throws Exception {
		ArrayList<String> tabs = new ArrayList<String>(TestDriver.driver.getWindowHandles());
		TestDriver.driver.switchTo().window(tabs.get(n));
	}

	// Switch back to the first window
	public void switchToPreviousTab() throws Exception {
		ArrayList<String> tabs = new ArrayList<String>(TestDriver.driver.getWindowHandles());
		TestDriver.driver.close();
		TestDriver.driver.switchTo().window(tabs.get(tabs.size() - 2));
	}

	//Closes a specified number of tab windows starting from the last tab of the browser
	public void closeNoOfTabs(int noOfTabs) throws Exception {
		ArrayList<String> tabs = new ArrayList<String>(TestDriver.driver.getWindowHandles());
		int n = tabs.size() - 1;

		for (; noOfTabs != 0; n--, noOfTabs--)
			TestDriver.driver.switchTo().window(tabs.get(n)).close();

		TestDriver.driver.switchTo().window(tabs.get(n));
	}

	// Opens a new tab in the browsers
	public void openNewTab() throws Exception {
		js.executeScript("window.open()");
	}

	/// <summary>Closes the browser</summary>
	public void closeBrowserIfOpen() throws Exception {
		if (TestDriver.driver != null)
			TestDriver.driver.quit();
	}

	// Switch to the frame using it's name
	public void switchToFrame(String frameName) throws Exception {
		TestDriver.driver.switchTo().frame(frameName);
		waitFor(3);
	}

	// <summary>Validate that the URL contains the parameterized value
	public void ValidateURLContains(String url) throws Exception {
		if(waitUntilUrlContains(url))
			report("PASS", "The URL includes " + url, false);
		else
			report("FAIL", "The URL doesn't includes " + url, true);
	}

	// Validate that the URL in a new tab contains the parameterized value
	public void ValidateURLContainsInNewTab(String url) throws Exception {
		switchToTab(2);
		ValidateURLContains(url);
		switchToPreviousTab();
	}

	// Validate the title of the page
	public void ValidatePageTitle(String title) throws Exception {
		if (TestDriver.driver.getTitle().equalsIgnoreCase(title))
			report("PASS", title + "is the title of the page as expected", false);
		else
			report("ERROR", title + "is not the title of the page", true);
	}

	// Handle the privacy error page, if displayed
	public void HandleChromePrivacyError() throws Exception {
		if (isDisplayed(By.xpath("//*[contains(text(), 'Your connection is not private')]")))
		{
			click(By.xpath("//button[contains(text(), 'Advanced')]"));
			click(By.xpath("//a[@id='proceed-link']"));
		}
	}

	// Navigates back to the browser's previous page
	public void navigateBackward() throws Exception {
		TestDriver.driver.navigate().back();
	}

	// Navigates forward to the browser's next page</summary>
	public void navigateForward() throws Exception {
		TestDriver.driver.navigate().forward();
	}

	// Refresh the browser's page
	public void refreshPage() throws Exception {
		TestDriver.driver.navigate().refresh();
	}

	// Get the WebElement using the parameterized locator
	public WebElement getElement(By by) {
		WebElement ele = null;
		try {
			ele = TestDriver.driver.findElement(by);
		} catch (Exception e) { }
		return ele;
	}

	// Get the list of WebElements using the parameterized locator
	public List<WebElement> getElements(By by) {
		List<WebElement> ele = null;
		try {
			ele = TestDriver.driver.findElements(by);
		} catch (Exception e) {
		}
		return ele;
	}

	// Get the Select WebElement using the parameterized locator
	public Select getDropdown(By by) throws Exception {
		return new Select(getElement(by));
	}

	// Verifies if the element is displayed on the screen
	public boolean isDisplayed(By by) throws Exception {
		WebElement ele = getElement(by);
		if(ele == null)
			return false;

		return isDisplayed(ele);
	}

	// Verifies if the element is displayed on the screen
	public boolean isDisplayed(WebElement ele) throws Exception {
		if (ele.isDisplayed())
			return true;
		else
			return false;
	}

	// Verifies if the element is selected on the screen
	public boolean isSelected(By by) throws Exception {
		WebElement ele = getElement(by);
		if (ele == null)
			return false;

		return isSelected(ele);
	}

	// Verifies if the element is selected on the screen
	public boolean isSelected(WebElement ele) throws Exception {
		if (ele.isSelected())
			return true;
		else
			return false;
	}

	// Highlights the WebElement, if found using the parameterized locator
	public void highlight(By by) throws Exception {
		WebElement ele = getElement(by);
		if (ele != null)
			highlight(ele);
	}

	// Highlights the parameterized WebElement
	public void highlight(WebElement ele) throws Exception {
		js.executeScript("arguments[0].style.border='3px solid red'", ele);
		report("INFO", "Highlighting the field in UI", true);
		waitFor(2);
	}

	// Click on a WebElement
	public boolean click(WebElement ele, String...elementName) {
		try {
			ele.click();
			if(elementName.length != 0)
				report("PASS", elementName[0] + " is clicked successfully", false);
			return true;
			
		} catch (Exception e) {
			if(elementName.length != 0)
				report("FAIL", elementName[0] + " is not clicked", true);
			return false;
		}
	}

	public boolean click(By by, String...elementName) {
		try {
			getElement(by).click();
			if(elementName.length != 0)
				report("PASS", elementName[0] + " is clicked successfully", false);
			return true;
			
		} catch (Exception e) {
			if(elementName.length != 0)
				report("FAIL", elementName[0] + " is not clicked", true);
			return false;
		}
	}

	// Type into a WebElement
	public boolean type(WebElement ele, String strText, String...elementName) {
		try {
			ele.sendKeys(strText);
			if(elementName.length != 0)
				report("PASS", "The text '" + strText + "' is entered in the element '" + elementName[0] + "' successfully", false);
			return true;
			
		} catch (Exception e) {
			if(elementName.length != 0)
				report("FAIL", "The text '" + strText + "' is not entered in the element '" + elementName[0] + "'", true);
			return false;
		}
	}

	public boolean type(By by, String strText, String...elementName) {
		try {
			getElement(by).sendKeys(strText);
			if(elementName.length != 0)
				report("PASS", "The text '" + strText + "' is entered in '" + elementName[0] + "' successfully", false);
			return true;
			
		} catch (Exception e) {
			if(elementName.length != 0)
				report("FAIL", "The text '" + strText + "' is not entered in '" + elementName[0] + "'", true);
			return false;
		}
	}

	// Selects all of the text in the parameterized WebElement
	public void selectAllText(WebElement ele) throws Exception {
		ele.sendKeys(Keys.CONTROL + "a");
	}

	// Selects all of the text in the WebElement found using the parameterized locator
	public void selectAllText(By by) throws Exception {
		WebElement ele = getElement(by);
		if(ele != null)
			selectAllText(ele);
	}

	// Select from a drop-down using Visible Text
	public boolean selectDropdown_ByVisibleText(Select ele, String strVisibleText, String...elementName) {
		try {
			ele.selectByVisibleText(strVisibleText);
			if(elementName.length != 0)
				report("PASS", "The option '" + strVisibleText + "' is selected for '" + elementName[0] + "' successfully", false);
			return true;
			
		} catch (Exception e) {
			if(elementName.length != 0)
				report("FAIL", "The option '" + strVisibleText + "' is not selected for '" + elementName[0] + "'", true);
			return false;
		}
	}

	public boolean selectDropdown_ByVisibleText(By by, String strVisibleText, String...elementName) {
		try {
			getDropdown(by).selectByVisibleText(strVisibleText);
			if(elementName.length != 0)
				report("PASS", "The option '" + strVisibleText + "' is selected for '" + elementName[0] + "' successfully", false);
			return true;
			
		} catch (Exception e) {
			if(elementName.length != 0)
				report("FAIL", "The option '" + strVisibleText + "' is not selected for '" + elementName[0] + "'", true);
			return false;
		}
	}

	// Select from a drop-down using it's Index
	public boolean selectDropdown_ByIndex(Select ele, int index) {
		try {
			ele.selectByIndex(index);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public boolean selectDropdown_ByIndex(By by, int index) {
		try {
			getDropdown(by).selectByIndex(index);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	// Select from a drop-down using it's Value
	public boolean selectDropdown_ByValue(Select ele, String value, String...elementName) {
		try {
			ele.selectByValue(value);
			if(elementName.length != 0)
				report("PASS", "The option '" + value + "' is selected for '" + elementName[0] + "' successfully", false);
			return true;
			
		} catch (Exception e) {
			if(elementName.length != 0)
				report("FAIL", "The option '" + value + "' is not selected for '" + elementName[0] + "'", true);
			return false;
		}
	}

	public boolean selectDropdown_ByValue(By by, String value, String...elementName) {
		try {
			getDropdown(by).selectByValue(value);
			if(elementName.length != 0)
				report("PASS", "The option '" + value + "' is selected for '" + elementName[0] + "' successfully", false);
			return true;
			
		} catch (Exception e) {
			if(elementName.length != 0)
				report("FAIL", "The option '" + value + "' is not selected for '" + elementName[0] + "'", true);
			return false;
		}
	}

	// Verify if the text in an element is empty, will still continue with the test case execution
	public void verifyIfTextIsNotEmpty(WebElement ele, String strMessage) throws Exception {
		if (ele.getText().trim() == null || ele.getText().trim().length() <= 0)
			report("PASS", "PASSED : " + strMessage, false);
		else
			report("ERROR", "ERROR : " + strMessage, true);
	}

	public void verifyIfTextIsNotEmpty(By by, String strMessage) throws Exception {
		if (getElement(by) == null)
			report("ERROR", "ERROR : " + strMessage + " (Element not available)", true);
		else if (getElement(by).getText().trim() == null || getElement(by).getText().trim().length() <= 0)
			report("PASS", "PASSED : " + strMessage, false);
		else
			report("ERROR", "ERROR : " + strMessage, true);
	}

	// Assert if the text in an element is empty, will stop the current test case execution
	public void assertIfTextIsNotEmpty(WebElement ele, String strMessage) throws Exception {
		if (ele.getText().trim() == null || ele.getText().trim().length() <= 0)
			report("PASS", "PASSED : " + strMessage, false);
		else
			report("FAIL", "FAILED : " + strMessage, true);
	}

	public void assertIfTextIsNotEmpty(By by, String strMessage) throws Exception {
		if (getElement(by) == null)
			report("FAIL", "FAILED : " + strMessage + " (Element not available)", true);
		else if (getElement(by).getText().trim() == null || getElement(by).getText().trim().length() <= 0)
			report("PASS", "PASSED : " + strMessage, false);
		else
			report("FAIL", "FAILED : " + strMessage, true);
	}

	// Verify the text in an element against the parameterized text, will still continue with the test case execution
	public void verifyElementText(WebElement ele, String strExpectedText) throws Exception {
		String strActualText = ele.getText();

		if (strActualText.equalsIgnoreCase(strExpectedText))
			report("PASS", "PASSED : The expected text '" + strExpectedText + "' is displayed on the screen", false);
		else
			report("ERROR", "ERROR : The expected text '" + strExpectedText + "' is not displayed on the screen", true);
	}

	public void verifyElementText(By by, String strExpectedText) throws Exception {
		if (getElement(by) == null) {
			report("ERROR", "ERROR : The expected text '" + strExpectedText + "' is not displayed (Element not available)", true);
			return;
		}

		String strActualText = getElement(by).getText();

		if (strActualText.equalsIgnoreCase(strExpectedText))
			report("PASS", "PASSED : The expected text '" + strExpectedText + "' is displayed on the screen", false);
		else
			report("ERROR", "ERROR : The expected text '" + strExpectedText + "' is not displayed on the screen", true);
	}

	// Assert the text in a WebElement against the parameterized text, will stop the current test case execution
	public void assertElementText(WebElement ele, String strExpectedText) throws Exception {
		String strActualText = ele.getText();

		if (strActualText.equalsIgnoreCase(strExpectedText))
			report("PASS", "PASSED : The expected text '" + strExpectedText + "' is displayed on the screen", false);
		else
			report("FAIL", "FAIL : The expected text '" + strExpectedText + "' is not displayed on the screen", true);
	}

	public void assertElementText(By by, String strExpectedText) throws Exception {
		if (getElement(by) == null) {
			report("FAIL", "FAILED : The expected text '" + strExpectedText + "' is not displayed (Element not available)", true);
			return;
		}

		String strActualText = getElement(by).getText();

		if (strActualText.equalsIgnoreCase(strExpectedText))
			report("PASS", "PASSED : The expected text '" + strExpectedText + "' is displayed on the screen", false);
		else
			report("FAIL", "FAILED : The expected text '" + strExpectedText + "' is not displayed on the screen", true);
	}

	// Verify if the WebElement exists, will still continue with the test case execution
	public void verifyPresence(By by, String strMessage) throws Exception {
		if (getElement(by) != null)
			report("PASS", "PASSED : " + strMessage, false);
		else
			report("ERROR", "ERROR : " + strMessage, true);
	}

	// Assert if the WebElement exists, will stop the current test case execution
	public void assertPresence(By by, String strMessage) throws Exception {
		if (getElement(by) != null)
			report("PASS", "PASSED : " + strMessage, false);
		else
			report("FAIL", "FAILED : " + strMessage, true);
	}

	// Navigate To Menu
	public boolean goToMenu(By mainMenu, By... menuItem) {
		boolean actionPerformed = false;
		try {
			Actions action = new Actions(TestDriver.driver);
			WebElement Mainmenu = getElement(mainMenu);
			if (menuItem.length > 0) {
				action.moveToElement(Mainmenu).build().perform();
				for (int i = 0; i < menuItem.length; i++) {
					By css = menuItem[i];
					if (i == menuItem.length - 1)
						action.moveToElement(new WebDriverWait(TestDriver.driver, 2)
								.until(ExpectedConditions.visibilityOfElementLocated(css))).click().build().perform();
					else
						action.moveToElement(new WebDriverWait(TestDriver.driver, 2)
								.until(ExpectedConditions.visibilityOfElementLocated(css))).build().perform();
				}
				actionPerformed = true;
			} else {
				action.moveToElement(Mainmenu).build().perform();
				actionPerformed = true;
			}
		} catch (Exception ex) {
			actionPerformed = false;
		}

		// If actionPerformed is true then the navigation was successful, else the navigation failed
		return actionPerformed;
	}

	// Explicitly wait until element presence is located
	public WebElement waitUntilElementPresent(By by) throws Exception {
		return new WebDriverWait(TestDriver.driver, 30).until(ExpectedConditions.presenceOfElementLocated(by));
	}

	// Explicitly wait until element goes invisible
	public boolean waitUntilElementInvisible(By by) throws Exception {
		return new WebDriverWait(TestDriver.driver, 30).until(ExpectedConditions.invisibilityOfElementLocated(by));
	}

	// Explicitly wait until element goes invisible
	public boolean waitUntilElementInvisible(WebElement ele) throws Exception {
		return new WebDriverWait(TestDriver.driver, 30).until(ExpectedConditions.invisibilityOf(ele));
	}

	// Explicitly wait until element becomes visible
	public WebElement waitUntilElementVisible(By by) throws Exception {
		return new WebDriverWait(TestDriver.driver, 30).until(ExpectedConditions.visibilityOfElementLocated(by));
	}

	// Explicitly wait until element is clickable
	public WebElement waitUntilElementClickable(By by) throws Exception {
		return new WebDriverWait(TestDriver.driver, 30).until(ExpectedConditions.elementToBeClickable(by));
	}

	// Explicitly wait until element is clickable
	public WebElement waitUntilElementClickable(WebElement ele) throws Exception {
		return new WebDriverWait(TestDriver.driver, 30).until(ExpectedConditions.elementToBeClickable(ele));
	}

	// Explicitly wait until the browser contains the parameterized URL
	public boolean waitUntilUrlContains(String url) throws Exception {
		return new WebDriverWait(TestDriver.driver, 30).until(ExpectedConditions.urlContains(url));
	}

	// Scrolling methods
	public void scrollToTop() throws Exception {
		js.executeScript("window.scrollTo(0, 0);");
	}

	public void scrollToBottom() throws Exception {
		js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
	}

	// Scrolls to the parameterized coordinates of the page
	public void ScrollToCoordinates(int x, int y) throws Exception {
		js.executeScript("window.scrollTo(arguments[0], arguments[1]);", x, y);
	}

	public void scrollInToView(WebElement ele) throws Exception {
		js.executeScript("arguments[0].scrollIntoView(true);", ele);
	}

	public void scrollInToView(By by) throws Exception {
		js.executeScript("arguments[0].scrollIntoView(true);", getElement(by));
	}

	// Generate random text
	public String getRandomText() throws Exception {
		String randomValue = Integer.toString((int) (Math.random() * 1000000000));
		return "Test_" + randomValue.substring(0, 5);
	}

	// Generate random number
	public int randomNumber(int limit) {
		return new Random().nextInt(limit) + 1;
	}

	// Double Click an element
	public boolean doubleClick(By by) {
		try {
			builder = new Actions(TestDriver.driver);
			builder.doubleClick(getElement(by)).build().perform();
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	// Click and drag an element from one place to another using WebElements
	public boolean clickAndDrag(WebElement source, WebElement target) {
		try {
			builder = new Actions(TestDriver.driver);
			builder.dragAndDrop(source, target).build().perform();
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	// Click and drag an element from one place to another using offset coordinates
	public boolean clickAndDrag(WebElement source, int xOffset, int yOffset) throws Exception {
		try {
			builder = new Actions(TestDriver.driver);
			builder.dragAndDropBy(source, xOffset, yOffset).build().perform();
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	// Move the mouse to the parameterized WebElement
	public boolean MouseHover(WebElement ele)
	{
		try
		{
			builder = new Actions(TestDriver.driver);
			builder.moveToElement(ele).build().perform();
			return true;
		}
		catch (Exception e) { return false; }
	}
	
	// Smoke Test to check if all the links in a web site are in working condition 
	public void checkLinks() throws Exception {

		int responseCode = 0;
		String url = null;
		boolean isPass = true;

		String driverUrl = TestDriver.driver.getCurrentUrl();
		String driverUrlHost = ((new URL(driverUrl)).getHost()).startsWith("www.")
				? (new URL(driverUrl)).getHost().substring(4) : (new URL(driverUrl)).getHost();

		List<WebElement> linksList = TestDriver.driver.findElements(By.xpath("//a"));

		for (WebElement link : linksList) {

			String httpUri = null;
			url = link.getAttribute("href");
			HttpURLConnection httpUrlConnection = null;

			if (null == url || url.isEmpty()) {
				continue;
			} else {
				try {
					URL httpUrl = new URL(url);

					if (url.contains(driverUrlHost)) {
						httpUri = httpUrl.getHost();
						httpUrlConnection = (HttpURLConnection) (httpUrl.openConnection());
						httpUrlConnection.setConnectTimeout(5000);
						httpUrlConnection.setReadTimeout(5000);
						httpUrlConnection.connect();
						responseCode = httpUrlConnection.getResponseCode();

						if (httpUri.equalsIgnoreCase(driverUrlHost) || httpUri.equalsIgnoreCase("www." + driverUrlHost)) {
							if (responseCode != 200)
								isPass = false;
							
							report("INFO", String.format("Response code for internal URL : \"%s\" is : \"%d\"", url, responseCode), false);
						} else if (httpUri.contains(driverUrlHost))
							report("INFO", String.format("Response code for external URL : \"%s\" is \"%d\"", url, responseCode), false);
					}
					
				} catch (Exception e) {
					
					if (httpUri != null) {
						if (httpUri.equalsIgnoreCase(driverUrlHost)) {
							isPass = false;
							report("INFO", String.format("There is an error in opening internal URL : \"%s\". Error : \"%s\"", url, e.getMessage()), false);
						} else if (httpUri.contains(driverUrlHost))
							report("INFO", String.format("There is an error in opening external URL : \"%s\". Error : \"%s\"", url, e.getMessage()), false);
					}
				}
			}
		}

		if (!isPass)
			report("FAIL", String.format("Links in the page are not fully working. Please check the logs for failure links."), false);
	}

	// Smoke Test to check if all the images in a web site are in working condition
	public void checkImages() throws Exception {

		HttpURLConnection httpUrlConnection = null;
		int responseCode = 0;
		String imageUrl = null;
		String fullUrl = null;

		boolean imagePresent;
		boolean isPass = true;

		List<WebElement> imagesList = TestDriver.driver.findElements(By.tagName("img"));

		for (WebElement image : imagesList) {

			try {
				imageUrl = image.getAttribute("src");
				
				if (imageUrl.equals("#")) {
					report("INFO", String.format("There is no src for the image with text : \"%s\" is present",
						(image.getText() != null && image.getText().trim() != "") ? image.getText() : image.getAttribute("alt")), false);
					isPass = false;
				}

				if (imageUrl.startsWith("/")) {
					String baseUrl = new URL(TestDriver.driver.getCurrentUrl()).getHost();
					fullUrl = baseUrl + imageUrl;
				}

				httpUrlConnection = (HttpURLConnection) (new URL(fullUrl)).openConnection();
				responseCode = httpUrlConnection.getResponseCode();

			} catch (Exception e) {
				isPass = false;
				report("INFO", String.format("There is an error in accessing the image with text : \"%s\"",
					(image.getText() != null && image.getText().trim() != "") ? image.getText() : image.getAttribute("alt")), false);
			}

			if (!((responseCode + "").startsWith("4") || (responseCode + "").startsWith("5")))
				report("INFO", String.format("Image with the src : \"%s\" is present", imageUrl), false);
			else
				report("INFO", String.format("Image with the src : \"%s\" is present", imageUrl), false);

			imagePresent = (boolean) ((JavascriptExecutor) TestDriver.driver).executeScript(
					"return arguments[0].complete && " + "typeof arguments[0].naturalWidth != \"undefined\" && "
							+ "arguments[0].naturalWidth > 0",
					image);

			if (imagePresent)
				report("INFO", String.format("The size of the image with the text : \"%s\" is visible",
					(image.getText() != null && image.getText().trim() == "") ? image.getText() : image.getAttribute("alt")), false);
			else {
				report("INFO", String.format("The size of the image with the text is not visible : \"%s\"",
					(image.getText() != null && image.getText().trim() != "") ? image.getText() : image.getAttribute("alt")), false);
				isPass = false;
			}

		}

		if (!isPass)
			report("FAIL", String.format("Images in the page are not fully present. Please check the logs for failure images."), false);
	}

	// Get the response of the API Request according to the inputs passed as parameters
	public Response getResponseFromAPI(String basicURI, String method, String[] pathParams, LinkedHashMap<String, String> queryParams, String token, LinkedHashMap<String, String> headers, String pathParamSeparator, String...payload)
	{
		//Setup Basic URI
		RestAssured.baseURI = basicURI;
		RequestSpecification request = RestAssured.given().header("Content-Type", "application/json");

		//Setup Pay Load data
		if (payload.length != 0)
			request = request.body(payload[0]);
		
		//Setup Authorization Token
		if (!(token.isEmpty() || token.length() == 0))
			request = request.header("Authorization", token);

		//Setup Query Parameters
		if (queryParams != null)
			request = request.queryParams(queryParams);

		//Setup Headers
		if (headers != null)
			request = request.headers(headers);
		
		//Setup Path Parameters
		if(pathParams != null) {
			String pathParamString = "";
			for(int i = 1; i <= pathParams.length; i++)
				pathParamString += "/{pathParam" + i + "}";
			
			switch(method.toUpperCase())
			{
				case "GET": return request.get(pathParamString, (Object[])pathParams);
				case "POST": return request.post(pathParamString, (Object[])pathParams);
				case "DELETE": return request.delete(pathParamString, (Object[])pathParams);
				case "PUT": return request.put(pathParamString, (Object[])pathParams);
				case "PATCH": return request.patch(pathParamString, (Object[])pathParams);
				default: return request.get(pathParamString, (Object[])pathParams);
			}
		}
		
		else {
			switch(method.toUpperCase())
			{
				case "GET": return request.get();
				case "POST": return request.post();
				case "DELETE": return request.delete();
				case "PUT": return request.put();
				case "PATCH": return request.patch();
				default: return request.get();
			}
		}		
	}
}