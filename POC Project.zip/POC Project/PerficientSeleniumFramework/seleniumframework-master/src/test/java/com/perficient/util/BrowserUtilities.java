package com.perficient.util;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.logging.LoggingPreferences;
//import org.openqa.selenium.phantomjs.PhantomJSDriver;
//import org.openqa.selenium.phantomjs.PhantomJSDriverService;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.perficient.core.TestDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BrowserUtilities {

	private static RemoteWebDriver driver;

	// derive the required Browser
	public static RemoteWebDriver getBrowser(String browserName, String nodeUrl) throws MalformedURLException {
		if(browserName == null) {
			driver = getChromeDriver(nodeUrl);
		} else if (browserName.equalsIgnoreCase("FF") || browserName.equalsIgnoreCase("Firefox")) {
			driver = getFirefoxBrowser(nodeUrl);
		} else if (browserName.equalsIgnoreCase("IE") || browserName.equalsIgnoreCase("InternetExplorer")) {
			driver = getInternetExplorerDriver(nodeUrl);
		} else if (browserName.equalsIgnoreCase("Chrome")) {
			driver = getChromeDriver(nodeUrl);
	/*	} else if(browserName.equalsIgnoreCase("Phantom")) {
			driver = getPhantomJS(nodeUrl);*/
		} else {
			driver = getChromeDriver(nodeUrl);
		}
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Integer.parseInt(TestDriver.props.getProperty("timeout")),
				TimeUnit.SECONDS);
		return driver;
	}

	// load FF browser and enable the logs
	public static RemoteWebDriver getFirefoxBrowser(String nodeUrl) throws MalformedURLException {
		new DesiredCapabilities();
		DesiredCapabilities capabilities = DesiredCapabilities.firefox();

		LoggingPreferences logs = new LoggingPreferences();
		logs.enable(LogType.BROWSER, Level.ALL);
		logs.enable(LogType.CLIENT, Level.ALL);
		logs.enable(LogType.DRIVER, Level.INFO);
		logs.enable(LogType.PERFORMANCE, Level.ALL);
		logs.enable(LogType.PROFILER, Level.ALL);
		logs.enable(LogType.SERVER, Level.ALL);
		capabilities.setCapability(CapabilityType.LOGGING_PREFS, logs);

		WebDriverManager.firefoxdriver().setup();
		if (nodeUrl != null)
			driver = new RemoteWebDriver(new URL(nodeUrl), capabilities);
		else
			driver = new FirefoxDriver(capabilities);
		return driver;
	}

	// load IE browser and enable the logs
	public static RemoteWebDriver getInternetExplorerDriver(String nodeUrl) throws MalformedURLException {
		new DesiredCapabilities();
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		capabilities.setCapability("ignoreZoomSetting", true);
		capabilities.setCapability("requireWindowFocus", true);

		LoggingPreferences logs = new LoggingPreferences();
		logs.enable(LogType.BROWSER, Level.ALL);
		logs.enable(LogType.CLIENT, Level.ALL);
		logs.enable(LogType.DRIVER, Level.INFO);
		logs.enable(LogType.PERFORMANCE, Level.ALL);
		logs.enable(LogType.PROFILER, Level.ALL);
		logs.enable(LogType.SERVER, Level.ALL);
		capabilities.setCapability(CapabilityType.LOGGING_PREFS, logs);
		
		capabilities.setJavascriptEnabled(true);
		WebDriverManager.iedriver().setup();
		if (nodeUrl != null)
			driver = new RemoteWebDriver(new URL(nodeUrl), capabilities);
		else
			driver = new InternetExplorerDriver(capabilities);
		return driver;
	}

	// load Chrome browser and enable the logs
	@SuppressWarnings("deprecation")
	public static RemoteWebDriver getChromeDriver(String nodeUrl) throws MalformedURLException {
		new DesiredCapabilities();
		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);

		ChromeOptions options = new ChromeOptions();
		options.addArguments("--test-type");
		options.addArguments("--no-sandbox");
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);

		LoggingPreferences logs = new LoggingPreferences();
		logs.enable(LogType.BROWSER, Level.ALL);
		logs.enable(LogType.DRIVER, Level.INFO);
		logs.enable(LogType.PERFORMANCE, Level.ALL);
		capabilities.setCapability(CapabilityType.LOGGING_PREFS, logs);

		WebDriverManager.chromedriver().setup();
		if (nodeUrl != null)
			driver = new RemoteWebDriver(new URL(nodeUrl), capabilities);
		else
			driver = new ChromeDriver(capabilities);
		return driver;
	}

	// load PhantomJS browser and enable the logs
	/*public static RemoteWebDriver getPhantomJS(String nodeUrl) throws MalformedURLException {
		new DesiredCapabilities();
		DesiredCapabilities capabilities = DesiredCapabilities.phantomjs();
		capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);

		String[] cli_args = new String[] { "--ignore-ssl-errors=yes", "--ssl-protocol=yes", "--web-security=no" };
		capabilities.setCapability(PhantomJSDriverService.PHANTOMJS_CLI_ARGS, cli_args);
		capabilities.setJavascriptEnabled(true);

		LoggingPreferences logs = new LoggingPreferences();
		logs.enable(LogType.BROWSER, Level.ALL);
		logs.enable(LogType.DRIVER, Level.INFO);
		logs.enable(LogType.PERFORMANCE, Level.ALL);
		capabilities.setCapability(CapabilityType.LOGGING_PREFS, logs);

		WebDriverManager.phantomjs().setup();
		if (nodeUrl != null)
			driver = new RemoteWebDriver(new URL(nodeUrl), capabilities);
		else
			driver = new PhantomJSDriver(capabilities);
		return driver;
	}*/

}
