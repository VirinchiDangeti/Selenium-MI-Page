/**
 * TestNG class which gets called for every test case. 
 * This is the driver class which runs for each test case. 
 * It reads the corresponding testdata from the input sheet and runs the actual test method 
 * and writes back the test results to the output sheet.
 * 
 */

package com.perficient.core;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.util.LinkedHashMap;
import java.util.Properties;
import java.util.regex.Pattern;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.perficient.util.BrowserUtilities;
import com.perficient.util.CommonUtilities;
import com.perficient.util.ExtentManager;
import com.perficient.util.IOUtil;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

public class TestDriver extends CommonUtilities {

	public static LinkedHashMap<String, String> data;
	public static RemoteWebDriver driver;
	public static ExtentReports extent;
	public static ExtentTest test;
	public static Properties props;
	public String databaseName;
	public String databaseURL;
	public String databaseUsername;
	public String databasePassword;
	int intCurrentIteration = -1;
	static int iterationCount = -1;
	static String nodeUrl = null;
	static String[] browserList = new String[10];
	static String executionLevel;

	// BeforeSuite sets up the configuration file, the HTML output files and database properties
	@Parameters("grid")
	@BeforeSuite
	public void suiteSetup(ITestContext context, @Optional String grid) throws IOException {
		File file = new File("user_config.properties");
		FileReader reader = new FileReader(file);
		props = new Properties();
		props.load(reader);
		extent = ExtentManager.Instance();
		
		//If execution to be carried out on grid
		if (grid != null) {
			if (grid.equals("true"))
				nodeUrl = props.getProperty("nodeUrl");
		}
		
		//Fetch the database details 
		databaseName = props.getProperty("databaseName");
		databaseURL = props.getProperty("databaseURL");
		databaseUsername = props.getProperty("databaseUsername");
		databasePassword = props.getProperty("databasePassword");
		
		//Get the browser list
		String[] arr = context.getCurrentXmlTest().getSuite().getFileName().split(Pattern.quote("\\"));
		String xmlName = arr[arr.length - 1];
		
		//Find whether the execution is initiated from Suite.xml or individual test class 
		if(xmlName.equalsIgnoreCase("Suite.xml")) {
			browserList = context.getCurrentXmlTest().getParameter("browsers").split(",");
			executionLevel = "Suite Level";
		}
		else {
			browserList[0] = "Chrome";
			executionLevel = "Test Level";
		}
	}

	@BeforeMethod
	public void InitializeTestIteration(Method result, ITestContext context) throws MalformedURLException {
		String browser;
		
		//Get the current method invocation count
		for (int i = 0; i < context.getAllTestMethods().length; i++) {
			if (result.getName().equals(context.getAllTestMethods()[i].getMethodName())) {
				intCurrentIteration = context.getAllTestMethods()[i].getCurrentInvocationCount() + 1;
				break;
			}
		}
		
		//Find whether the execution is initiated from Suite.xml or individual test class 
		if(executionLevel.equalsIgnoreCase("Suite Level")) {
			//Get the Browser to execute with and Iteration No# for fetching excel sheet data 
			if(browserList.length == 1)
				browser = browserList[0].trim();
			else {
				if(intCurrentIteration <= iterationCount)
					browser = browserList[0].trim();
				else {
					int a = (int) Math.ceil((double)intCurrentIteration / iterationCount) - 1;
					browser = browserList[a].trim();
					
					if(intCurrentIteration % iterationCount == 0)
						intCurrentIteration = iterationCount;
					else
						intCurrentIteration = intCurrentIteration % iterationCount;
				}
			}
		}
		else
			browser = "Chrome";
		
		//Get the data from the corresponding Input Sheet
		if (props.getProperty("whichinputfiletouse").equalsIgnoreCase("excel"))
			data = IOUtil.getInputData(result.getName(), intCurrentIteration);
		else if (props.getProperty("whichinputfiletouse").equalsIgnoreCase("json"))
			data = IOUtil.getInputDataFromJSON(result.getName(), intCurrentIteration);
		
		//Get the Web Driver of the browser mentioned in the parameters, depending on if it's UI or API test case
		String group = "";
		try {
			group = result.getAnnotation(Test.class).groups()[0];
		} catch (Exception e) { }
		
		if(!group.equals("API")) {
			driver = BrowserUtilities.getBrowser(browser, nodeUrl);
			js = ((JavascriptExecutor) driver);
		}
		
		//Start the extent reporting for the current test case being executed
		test = extent.startTest(data.get("TC_Name") + " [Iteration" + Integer.toString(intCurrentIteration) + " : " + browser + "]",
				data.get("TC_Description") + " [Browser : " + browser + "]");
	}

	//Get the number of iterations mentioned in input sheet
	@DataProvider(name = "data-provider")
	public static Object[][] dataProvider(Method result) {
		Object[][] obj;
		
		//Get the no. of input iterations for excel sheet
		if (props.getProperty("whichinputfiletouse").equalsIgnoreCase("json"))
			iterationCount = IOUtil.getNumOfChildNodesFromJSON(result.getName());
		else
			iterationCount = IOUtil.getNumOfChildNodesFromExcel(result.getName());
		
		//Find whether the execution is initiated from Suite.xml or individual test class 
		if(executionLevel.equalsIgnoreCase("Suite Level"))
			obj = new Object[iterationCount * browserList.length][0];
		else
			obj = new Object[iterationCount][0];
		
		return obj;
	}

	// All the tear down operations occur, since Reporting is done at the end of every test method
	@AfterMethod
	public void tearDown(ITestResult testResult) {
		if (driver != null)
			driver.quit();
		extent.endTest(test);
		data.clear();
	}

	// The extent reporting is done for each suite. The extent/HTML report is flushed and closed
	@AfterSuite
	public void flush() {
		extent.flush();
		extent.close();
	}

}