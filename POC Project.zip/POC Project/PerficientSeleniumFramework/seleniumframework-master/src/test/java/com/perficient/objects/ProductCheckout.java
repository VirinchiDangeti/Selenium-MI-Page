package com.perficient.objects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.perficient.core.TestDriver;

public class ProductCheckout extends TestDriver {
WebDriver driver;
	
    public ProductCheckout(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    
    
    //Defining all the required Webelements.
    @FindBy(xpath="//ancestor::div[@class='cart-bargains__container-left']//following-sibling::button[@class='cart-bargains__container-add xiaomi icon-cart-add icon-cart-add--able']")
    WebElement additionalItem_Button;
    
    @FindBy(xpath="//div[@class='cart-bargains__container-group-list']")
    WebElement additional_Item;
    
    @FindBy(xpath="//button[@class='cart__footer-checkout']")
    WebElement checkOut_Button;
    
    
    //Adding the Extra Additional Product
    public void extraProduct() throws Exception {
    	report("PASS", String.format("Additional Items are added "), false);
    	scrollInToView(additional_Item);
    	waitUntilElementClickable(additionalItem_Button);
    	waitFor(2);
    	click(additionalItem_Button);
    	waitFor(2);
    	click(checkOut_Button);
    	waitFor(2);   		
    }
    
    
}
