//package com.perficient.test;
//
//
//import org.testng.annotations.Test;
//
//import com.perficient.core.TestDriver;
//import com.perficient.objects.AllProductPage;
//import com.perficient.objects.HomePage;
//import com.perficient.objects.LoginPage;
//import com.perficient.objects.OrderSummary;
//import com.perficient.objects.ProductCheckout;
//import com.perficient.objects.ProductDetailsPage;
//import com.perficient.objects.ProductPage;
//
//public class POCFlowTest extends TestDriver {
//	private int pageCount = 0;
//
//	@Test (dataProvider="data-provider", dataProviderClass=TestDriver.class)
//	public void SampleTest() throws Exception{
//
//		open(data.get("URL"));
//		
//		// Defining the Home Page
//		HomePage home = new HomePage(driver);
//		// Calling the functions in HomePage
//		pageCount++;
//		home.openSignin();
//		printPageCount("Login Page");
//		pageCount++;
//		
//		
//		
//		//Defining the Login Page
//		LoginPage login =new LoginPage(driver);
//		//Calling the functions in Login Page
//		report("INFO", String.format("TEST_ID :1, Scenario: Login with Invalid credentials"), false);
//		login.accountEmail(data.get("inValid_Username"));
//		login.accountPassword(data.get("inValid_Password"));
//		login.signinAcc();
//		login.printErrorMessage();
//		login.clearCredentials();
//		login.userTextErrorMessage();
//		login.passwordTextErrorMessage();
//		report("INFO", String.format("TEST_ID :2, Scenario: Login with valid credentials"), false);
//		login.accountEmail(data.get("valid_Username"));
//		login.accountPassword(data.get("valid_Password"));
//		login.signinAcc();
//		login.printErrorMessage();
//		pageCount++;
//		
//		
//		home.phonePage(); // Redirecting to Home Page and clicking on Phone Category
//		pageCount++;
//		
//		
//		//Defining the Products Page
//		report("INFO", String.format("TEST_ID :3, Scenario: User selecting the required product by navigating through pages"), false);
//		report("INFO", String.format("User is navigated to all phones page by clicking on Phone in nav bar"), false);
//		AllProductPage AllPage = new AllProductPage(driver);
//		report("INFO", String.format("User scrolls down to redmi phones and clicks on it"), false);
//		AllPage.redmiPhonePage(); // Using this function user is redirected to Redmi Phones Page.
//		pageCount++;
//		
//		
//		//Defining the Redmi Phone Page
//		report("INFO", String.format("User navigated to Redmi Phones page"), false);
//		ProductPage RedmiPage = new ProductPage(driver);
//		report("INFO", String.format("User selecting filter only products which are in stock"), false);
//		RedmiPage.checkStock(); //Function to filter only products which are in stock
//		report("INFO", String.format("User selecting the required phone"), false);
//		RedmiPage.phoneSelection(); //Selecting the phone with variant and color and checking the PRICE of the phone
//		pageCount++;
//		
//		
//		//Defining the Product Details Page
//		ProductDetailsPage Product = new ProductDetailsPage(driver);
//		//Calling the functions form the Product Details Page
//		report("INFO", String.format("TEST_ID :4, Scenario: User entering Invalid Pincode"), false);
//		Product.enterPincode(data.get("inValid_Pincode"));	
//		Product.pincodeSubmit();
//		report("INFO", String.format("TEST_ID :5, Scenario: User entering valid pincode"), false);;
//		Product.enterPincode(data.get("Valid_pincode"));
//		Product.pincodeSubmit();
//		Product.buyNow();
//		printPageCount("Phone Page");
//		pageCount++;
//		
//		
//		
//		//Defining the Checkout Page
//		report("INFO", String.format("TEST_ID :6, Scenario: User navigated to additional page and adding an item"), false);
//		ProductCheckout Checkout = new ProductCheckout(driver);
//		Checkout.extraProduct(); //Selecting any extra product along with the Phone.
//		report("INFO", String.format("An additional item is added to cart"), false);
//		waitFor(2);
//		printPageCount("Checkout Page");
//		pageCount++;
//		
//		
//		//Defining the Order Summary Page
//		report("INFO", String.format("TEST_ID :7, Scenario: User navigated to order summary page and filling the details"), false);
//		OrderSummary order = new OrderSummary(driver);
//		report("INFO", String.format("User filling out the required details"), false);
//		order.checkout_Details(); //Filling all the required details in the respective fields and checking the PRICE.
//		waitFor(5);
//		pageCount++;
//
//
//		//For accessing the list of authorized stores using Windows Method.
//		report("INFO", String.format("TEST_ID :8, Scenario:User navigated Authorized store list page which opened in new window"), false);
//		home.authorizedStoreLink();
//		printPageCount("Authorized store");
//		pageCount++;
//		
//		//For Clearing the items added in the cart
//		home.clearCart();
//		
//		
//		//Redirecting back to the home page and sign out from the account.
//		report("INFO", String.format("TEST_ID :9, Scenario:User sigining out of MI account"), false);
//		home.accountSignOut();
//		waitFor(5);
//		report("INFO", String.format("User after sigining out of MI account"), false);
//		home.signinDropdown();
//		waitFor(5);
//		pageCount++;
//		
//		
//		System.out.println("No of pages navigated throughout the flow: "+pageCount);
//}
//    private void printPageCount(String pageName) {
//    	report("INFO", String.format("Number of pages visited for " + pageName + ": " + pageCount), false);
//        System.out.println("Number of pages visited for " + pageName + ": " + pageCount);
//    }
//}