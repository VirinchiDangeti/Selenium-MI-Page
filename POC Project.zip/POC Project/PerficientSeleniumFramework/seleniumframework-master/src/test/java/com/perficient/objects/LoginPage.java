package com.perficient.objects;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.perficient.core.TestDriver;

public class LoginPage extends TestDriver {
	WebDriver driver;
	
	
    public LoginPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    
    
    //Defining the required Webelements.
    @FindBy(xpath="//input[@name='account']")
    WebElement userID_Input;
    
    @FindBy(xpath="//input[@name='password']")
    WebElement userPassword_Input;
    
    @FindBy(xpath="//button[text()='Sign in']")
    WebElement signIn_Button;
    
    @FindBy(xpath="//div[contains(text(),'password you entered')]")
    WebElement errorMessage;
    
    @FindBy(xpath="//div[contains(text(),'Enter your email address')]")
    WebElement userID_Error;
    
    @FindBy(xpath="//div[contains(text(),'Enter your password')]")
    WebElement password_Error;
    
    

    //Asking the user to enter the input
    public void accountEmail(CharSequence user) {
    	userID_Input.sendKeys(user);
    	waitFor(1);
    }

    
    //Asking the user to enter the input
	public void accountPassword(CharSequence user) {
		userPassword_Input.sendKeys(user);
		waitFor(1);
	}
	
	
	//Clicking on the signin button
	public void signinAcc() throws Exception {
		report("PASS", String.format(" User trying to Signin "), false);
		waitUntilElementClickable(signIn_Button);
		signIn_Button.click();
		waitFor(2);
	}
	
	//Printing the displayed error message
	public void printErrorMessage() {
		try {
		if(errorMessage.isDisplayed()) {
			report("PASS", String.format("When User entered Invalid Credentials "), true);
			report("PASS", String.format(errorMessage.getText()), false);
		}
		}
		catch (NoSuchElementException e) {
			report("INFO", String.format("User has entered valid credentials"), false);
		}
		waitFor(2);
	}
	
	
	//Clearing the Credentials
	public void clearCredentials() {
		report("INFO", String.format("Input fields are cleared"), false);
		userID_Input.clear();
		userPassword_Input.clear();
		waitFor(2);
	}
	
	
	//Printing the Error Message which is displayed when the field is empty
	public void userTextErrorMessage() {
		try {
			if (userID_Input == null || ((CharSequence) userID_Input.getText()).isEmpty() ) {
				report("PASS", String.format(userID_Error.getText()), false);
			    System.out.println(userID_Error.getText());
			} 
		}
		catch (NoSuchElementException e) {
			report("INFO", String.format("Username not Empty"), false);
		    System.out.println("Username not Empty");
		}
	}
	
	
	//Printing the Error Message which is displayed when the field is empty
	public void passwordTextErrorMessage() {
		try {
		if (userPassword_Input == null || ((CharSequence) userPassword_Input.getText()).isEmpty()) {
			report("PASS", String.format(password_Error.getText()), false);
			System.out.println(password_Error.getText());
		    report("PASS", String.format("When User left the fields empty "), true);
		} 
		}
		catch (NoSuchElementException e) {
		    System.out.println("Password not Empty");
		}
	}
}
