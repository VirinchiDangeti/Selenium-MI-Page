package com.perficient.objects.enterprise;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.perficient.core.TestDriver;

public class CancellationPage extends TestDriver {
WebDriver driver;
	
    public CancellationPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    
    @FindBy(xpath="//h1[@class='resflow__header-info-title']")
	WebElement cancellationPage_title;
    
    @FindBy(xpath="//span[@class='paragraph-bold']")
	WebElement confirmationNumber_text;
    
}
