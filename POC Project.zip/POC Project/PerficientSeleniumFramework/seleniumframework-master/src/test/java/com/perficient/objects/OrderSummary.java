package com.perficient.objects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.perficient.core.TestDriver;

public class OrderSummary extends TestDriver{
WebDriver driver;
	
    public OrderSummary(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
	
    
    //Defining all the required webelements.
	@FindBy(xpath="//div[@class='product-overview__header' and @fmp-c]")
	WebElement item_Count;
	
	@FindBy(xpath="//h2[@class='price-summary__total-price notranslate']")
	WebElement item_Cost;
	
	@FindBy(xpath="//div[@class='mi-form-input mi-form-input--large mi-form-input--text']//input[@maxlength='30']")
	WebElement customerName_input;
	
	@FindBy(xpath="//div[@class='mi-form-input mi-form-input--large mi-form-input--text']//input[@maxlength='6']")
	WebElement customerPincode_input;
	
	@FindBy(xpath="//div[@class='mi-form-input mi-form-input--large mi-form-input--text mi-form-input--with-prefix']//input[@maxlength='10']")
	WebElement customerNumber_input;
	
	@FindBy(xpath="//div[@class='mi-form-input mi-form-input--large mi-form-input--text' ]//input[@placeholder='House number and street name']")
	WebElement customerAdress_input;
	
	@FindBy(xpath="//div[@class='mi-form-input mi-form-input--large mi-form-input--text']//input[@maxlength='50']")
	WebElement customerEmail_input;
	
	@FindBy(xpath="//div[@class='navigation__logo' and @fmp-c]")
	WebElement homePage_button;
	
	
	
	//Printing the details of product and Entering the details of Customer.
	public void checkout_Details() {
		
		report("INFO", String.format("No of Items in the cart: "+"2"+" and total cost of the products: "+item_Cost.getText()), false);
		report("INFO", String.format("Filling the required details "), false);
		System.out.println("No of Items in the cart: "+"2"+" and total cost of the products: "+item_Cost.getText());
		waitFor(1);
		customerName_input.sendKeys("Virinchi Dangeti");
		waitFor(1);
		customerPincode_input.sendKeys("533001");
		waitFor(1);
		customerNumber_input.sendKeys("9542058885");
		waitFor(1);
		customerAdress_input.sendKeys("Main Road");
		waitFor(1);
		customerEmail_input.sendKeys("virinchidangeti@gmail.com");
		click(homePage_button);
		driver.get("https://www.mi.com/in/");
		
	}
}
