package com.perficient.objects.enterprise;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.perficient.core.TestDriver;

public class DetailsPage extends TestDriver {
WebDriver driver;
	
    public DetailsPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    
    @FindBy(xpath="//input[@id='firstName']")
	WebElement firstName_input;
    
    @FindBy(xpath="//input[@name='lastName']")
	WebElement lastName_input;
    
    @FindBy(xpath="//input[@id='phoneNumber']")
	WebElement phoneNumber_input;
    
    @FindBy(xpath="//input[@id='email']")
	WebElement email_input;
    
    @FindBy(xpath="//input[@name='expediteQuestion' and @value='NO']")
	WebElement expediteQuesNo_option;
    
    @FindBy(xpath="//button[@data-test-id='no-flight-button']")
	WebElement noFlight_button;
    
    @FindBy(xpath="//button[@id='reviewSubmit']")
	WebElement reviewSubmit_button;
    
    public void customerDetails() throws Exception{
    	firstName_input.sendKeys("Virinchi");
    	waitFor(2);
    	lastName_input.sendKeys("Dangeti");
    	waitFor(2);
    	phoneNumber_input.sendKeys("9542058885");
    	waitFor(2);
    	report("PASS", String.format("Filling user information"), true);
    	email_input.sendKeys("Virinchidangeti@gmail.com");
    	waitFor(2);
    	expediteQuesNo_option.click();
    	waitFor(2);
    	noFlight_button.click();
    	waitFor(2);
    	reviewSubmit_button.click();
    }
    
}
