package com.perficient.objects.enterprise;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.perficient.core.TestDriver;

public class ConfirmationPage extends TestDriver {
WebDriver driver;
	
    public ConfirmationPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    
    @FindBy(xpath="//h1[@class='resflow__header-info-title']")
	WebElement confirmationPage_title;
    
    @FindBy(xpath="//span[@class='paragraph-bold']")
	WebElement confirmationNumber_text;
    
    @FindBy(xpath="//button[@class='cta cta--primary cta--large cta--fullWidth cta--noMargin' and @aria-label='Modify Reservation']")
	WebElement modifyReservation_Button;
    
    @FindBy(xpath="//button[@class='cta cta--primary cta--large cta--noMargin' and contains(text(),'Yes')]")
	WebElement modifyConfirmationYes_Button;
    
    @FindBy(xpath="//button[@class='cta cta--secondary cta--large cta--noMargin' and contains(text(),'No')]")
	WebElement modifyConfirmationNo_Button;
    
    @FindBy(xpath="//button[@class='cta cta--secondary cta--large cta--fullWidth cta--noMargin' and contains(text(),'Cancel Reservation')]")
	WebElement CancelReservation_Button;
    
    @FindBy(xpath="//button[@class='cta cta--primary cta--large cta--noMargin' and contains(text(),'Yes')]")
	WebElement CancelConfirmationYes_Button;
    
    public void cancellationFlow() throws Exception{
    	//System.out.println(confirmationPage_title.getText());
    	waitFor(2);
    	System.out.println(confirmationNumber_text.getText());
    	waitFor(2);
    	report("PASS", String.format("Confirmation Page"), true);
    	CancelReservation_Button.click();
    	waitFor(5);
    	CancelConfirmationYes_Button.click();
    	waitFor(10);
    	
    }
    
    public void modificationFlow() throws Exception{
    	waitFor(5);
    	System.out.println(confirmationNumber_text.getText());
    	waitFor(2);
    	report("PASS", String.format("Confirmation Page"), true);
    	modifyReservation_Button.click();
    	waitFor(5);
    	modifyConfirmationNo_Button.click();
    	waitFor(5);
    	modifyReservation_Button.click();
    	waitFor(5);
    	modifyConfirmationYes_Button.click();
    }

}
