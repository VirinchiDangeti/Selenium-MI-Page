package com.perficient.objects.enterprise;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.perficient.core.TestDriver;

public class HomePageEnterprise extends TestDriver {
	WebDriver driver;
	
    public HomePageEnterprise(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    
    @FindBy(xpath="//input[@class='rs-input__field selected']")
	WebElement location_input;
    
    @FindBy(xpath="//small[@class='location-group__item-select']")
	WebElement location_select;
    
    @FindBy(xpath="//button[@class='cta cta--primary cta--extra-large cta--fullWidth cta--noMargin']")
	WebElement browseVehicles_Button;
    
    @FindBy(xpath="//button[@class='cta cta--primary cta--large cta--noMargin']")
	WebElement Vehicle_select;
    
    @FindBy(xpath="//button[@class='cta cta--secondary cta--small cta--icons cta--noMargin cta--noWrap' and @aria-label='Add']")
	WebElement extras_Add;
    
    @FindBy(xpath="//button[@class='cta cta--primary cta--large cta--noMargin' and @aria-label='Continue to Review']")
	WebElement reviewContinue_Button;
    
    public void happyFlow() throws Exception {
    	report("PASS", String.format("Enterprise Home Page"), true);
		location_input.sendKeys("New York JFK International Airport");
		waitFor(10);
		location_select.click();
		waitFor(10);
		report("PASS", String.format("Select any LDT for Reservation"), true);
		browseVehicles_Button.click();
		waitFor(10);
		report("PASS", String.format("Random Vehicle is selected"), true);
		Vehicle_select.click();
		waitFor(10);
		report("PASS", String.format("Extras Page"), true);
		extras_Add.click();
		waitFor(20);
		reviewContinue_Button.click();
		waitFor(5);
		report("PASS", String.format("Review Page"), true);
		
		
    }
}
