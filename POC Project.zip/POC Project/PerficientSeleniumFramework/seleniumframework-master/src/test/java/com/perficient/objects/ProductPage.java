package com.perficient.objects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.perficient.core.TestDriver;

public class ProductPage extends TestDriver {
	WebDriver driver;
	
    public ProductPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    
    
    //Defining the required Webelements
    @FindBy(xpath="//span[text()='In stock']")
    WebElement inStock;
    
    @FindBy(xpath="//bdi[text()='Redmi Note 12 Pro 5G']//ancestor::div[@class='mi-product__item']")
    WebElement phone;
    
    @FindBy(xpath="//bdi[text()='Redmi Note 12 Pro 5G']//ancestor::div[@class='mi-product__item']//bdi")
    WebElement phoneNameTitle;
    
    @FindBy(xpath="//bdi[text()='Redmi Note 12 Pro 5G']//ancestor::div[@class='mi-product__item']//ul//li[@class='selector__item']//button[@class='selector__label selector__label--active']")
    WebElement phoneVariant;
    
    @FindBy(xpath="//bdi[text()='Redmi Note 12 Pro 5G']//ancestor::div[@class='mi-product__item']//ul//li[@class='selector__item']//button[contains(text(),'8 GB + 256 GB')]")
    WebElement selectPhoneVariant;
    
    @FindBy(xpath="//bdi[text()='Redmi Note 12 Pro 5G']//ancestor::div[@class='mi-product__item']//ul//li[@title='Onyx Black']")
    WebElement phoneColour;
    
    @FindBy(xpath="//bdi[text()='Redmi Note 12 Pro 5G']//ancestor::div[@class='mi-product__item']//strong")
    WebElement phoneCost;
    
    @FindBy(xpath="//bdi[text()='Redmi Note 12 Pro 5G']//ancestor::div[@class='mi-product__item']//a[@class='mi-btn mi-btn--primary mi-btn--normal mi-btn--light']")
    WebElement buyPhone_button;
  
    
    //Filtering only the products available in stock.
    public void checkStock() {
    	report("INFO", String.format("In stock filter is selected "), false);
    	if(inStock.isEnabled()==true) {
    		inStock.click();
			if(inStock.isSelected()==false) {
				report("INFO", String.format("Page is Displaying produt which are in stock"), false);
				System.out.println("Page is Displaying produt which are in stock");
			}
    	}
    }
    
    
    //Selecting or Checking the price of phone with required Variants.
    public void phoneSelection() throws Exception {
    	report("PASS", String.format("Required phone is selected "), false);
    	scrollInToView(phone);
    	report("INFO", String.format("Standard options selected are: "+ phoneNameTitle.getText()+", "+phoneVariant.getText()+", "+phoneCost.getText()), false);
    	System.out.println("Standard options selected are: "+ phoneNameTitle.getText()+", "+phoneVariant.getText()+", "+phoneCost.getText());
    	click(phoneColour);
    	click(selectPhoneVariant);
    	waitFor(4);
       	report("INFO", String.format("New Selected Varaint: "+ phoneNameTitle.getText()+", "+phoneVariant.getText()+", "+phoneCost.getText()), false);
    	System.out.println("New Selected Varaint: "+ phoneNameTitle.getText()+", "+phoneVariant.getText()+", "+phoneCost.getText());
    	click(buyPhone_button);
    }
}