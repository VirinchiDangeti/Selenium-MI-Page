package com.perficient.test.enterprise;

import org.testng.annotations.Test;

import com.perficient.core.TestDriver;
import com.perficient.objects.enterprise.ConfirmationPage;
import com.perficient.objects.enterprise.DetailsPage;
import com.perficient.objects.enterprise.HomePageEnterprise;

public class CancelReservationFlow extends TestDriver {
	@Test (dataProvider="data-provider", dataProviderClass=TestDriver.class)
	public void CancellationFlow() throws Exception{

		open("https://enterprise-use-aem.enterprise.com/en/home.html");
		waitFor(10);
		
		// Defining the Home Page
		HomePageEnterprise home = new HomePageEnterprise(driver);
		home.happyFlow();
		
		// Defining the Details Page
		DetailsPage details = new DetailsPage(driver);
		details.customerDetails();
		
		// Defining the Confirmation Page
		ConfirmationPage confirmation =new ConfirmationPage(driver);
		confirmation.cancellationFlow();
		waitFor(10);
		report("PASS", String.format("Reservation Cancelled"), true);
		
		//Defining the Cancellation Page
//		CancellationPage cancellation = new CancellationPage(driver);
//		cancellation.
}
}