# Selenium Java Framework
The Selenium Test Framework Proposal

# How to setup
---
The first step towards integrating or building the project would be to import the project work into the eclipse workspace. 

The user setup file (user_config.properties) is located at the root directory of your project. This file allows the configuration and customization of the various directories and wait times. Any changes to this file will reflect in the locations of the reports and required test data (Input.xls or Input.json). It is advised to not alter the names of the properties, rather, customize the directories alone.

### Test Data

The Test Data comprises of:
- the excel file – Input.xls which contains the values of the various “Common parameters” which are common to the entire test suite and the test level parameters in the succeeding rows which are common to a single test method. It also lets user to decide which test should be executed.
- the JSON file – Input.json which contains the values of the test case parameters mentioned under the test case name.

The user is to input all the necessary test data into this excel file maintaining the existing scheme:

- Each row representing a single @Test method.
- The User is advised to key in all the required values with the corresponding headers ensuring that the value under the Heading  **TC_Name** is the name of the **@Test Method** as this is the main identifier while getting data from the excel file.
- In case of Excel input sheet, each test case is marked as either **"Y"** or **"N"** under the heading **To Be Executed** to denote whether the test case is to be executed or not.

### Test Case Methods

The Test case, which is the function that performs the automated tests, should be prefixed with the @Test Annotation. It must be under the test package – **com.perficient.test**

Each @Test Method will be considered as a single test case. The following format is to be adhered:

- Each UI test case method should be prefixed with the Test annotation in the format: @Test (dataProvider="data-provider", dataProviderClass=TestDriver.class)
- Each API test case method should be prefixed with the Test annotation in the format: @Test (dataProvider="data-provider", dataProviderClass=TestDriver.class, groups= {"API"})
- The entire test method body must be enclosed within a try-catch block to handle scenarios when an exception is caught.
- Every Test method should call the report() function whenever a checkpoint is reached or a log is needed. If a screenshot is required, then the Boolean value “true” should be set as the last argument in the report() function.
- Utilization of the parameters linked hash map and the associated get() method to obtain the necessary values from the Input File
- The parameters map is present during the entire run time of the test method and houses all the important test parameters along with the suite level common parameters.

###Page Object Model
The Page object is a functional component of the Test suite acting as an object repository.
It contains all the objects and element instantiations housing the wrapper methods which can be called in the Test case. 

The execution of all the test cases is accomplished via the XML file **Suite.xml**. 

The following format is to be adhered:

- The XML file should contain the suite-test tags which either encloses package tags or class tags. This determines which of the test cases will be a part of the Test Execution and reporting.
- The XML file should contain a parameter tag "browser" which lists the browsers to be used for execution purpose. It can have 1 or more browsers mentioned as a comma-separated list.

At the end of execution, the user can view the reports that are generated as a HTML extent report file in the reports directory by default or in the user defined directory. The reports directory contains the HTML reports and the screenshots. 

# Components of the framework
---

### TestDriver

This is the class where all the TestNG annotated methods are present.

Here you modularize your program and break it down into a set of functionalities and based on the frequency of occurrence or calling of these functionalities, we categorize them under the corresponding before and after annotations.

There are 8 Before and After annotations.

- Before Suite - After Suite
- Before Test – After Test
- Before Class – After Class
- Before Method – After Method

Out of the above 8 annotations, The Test driver houses 4 annotations and their corresponding methods, along with a DataProvider annotation as well.

The Before Suite method invokes and sets up the various reporting functionalities, database configurations and loads the user properties file. This is performed once before the entire Testing Suite.

The Before method sets up the input data coming in from either the Excel or JSON file according to the test case currently being executed and the current data iteration, sets the browser to be used and starts the HTML extent report.

The After method quits the browser and clears the test data which was setup in Before method.

The After suite acts as a flush closing the HTML Extent reporting.

The Data Provider sets up the number of times a test case needs to be executed, which in turn depends on the no. of data iterations mentioned in the input file and the no. of browsers mentioned in Suite.xml.

### Suite.xml

This is the XML file that drives the whole test suite execution. It has various suite level and test level tags along with a browser parameter. The user is advised to give appropriate names for the suite tag and the test tags.

This is the file that acts as panel operating the entire test suite.

This file has a tag **<listeners> <listener class-name="com.perficient.core.AnnotationTest" /> </listeners>** that takes care of checking whether the test case is mentioned as **"Y"** under **To Be Executed** header in the input excel sheet.  

The user is to indent all the test cases within the ***<test> </test>*** tags.

The user can either perform the test at the class level using the **<class> <class name=” “> </class>** or at a package level using **<package> <package name=””> </package>**

The user is supposed to mention all the browsers on which the execution needs to be carried out within the **<parameter />** tag as a comma-separated list.

### AnnotationTest

This consists of functionalities to make sure whether a test case should be executed or not. For this process, the input sheet should always be Excel and the test cases are marked as "Y" or "N" in the input excel sheet under the header of "To Be Executed".

### User_Config Properties file

This houses all the user customizable fields such as the location of the test data, the location of the reports, the maximum wait time, etc. The user is allowed to modify the properties file as per the requirement. Though it is suggested to follow the established scheme.

### IOUtil

This is the main utilities class for the input data functionalities. It has methods to read data from excel spreadsheets and JSON files.

The getInputData accepts the String which is the name of the test method and an Integer which indicates the current iteration of the test case as parameters. Returns the LinkedHashMap of data read from the Input excel file (the corresponding row whose TC_Name is the same as the test method name and iteration number is same as the current iteration).

The getInputDataFromJSON accepts the String which is the name of the test method and an Integer which indicates the current iteration of the test case as parameters. Returns the LinkedHashMap of data read from the JSON file (the corresponding node whose TC_Name is the same as the test method name and iteration number is same as the current iteration).

The getNumOfChildNodesFromExcel accepts the String which is the name of the test method as a parameter. Returns the no. of data iterations mentioned for the the corresponding row whose TC_Name is the same as the test method name in the Input excel file.

The getNumOfChildNodesFromJSON accepts the String which is the name of the test method as a parameter. Returns the no. of data iterations mentioned for the the corresponding row whose TC_Name is the same as the test method name in the Input JSON file.

### BrowserUtilities

This utilities class is where the web driver element is setup and the event logging is enabled. The supported browsers are Firefox, Internet Explorer, Chrome, Phantom, etc.

### CommonUtilities

This class houses all the common utility methods such as the getScreenshot(), sendKeys(), getText(), isElementPresent(), pageLoadTimeout() and most importantly report(), checkLinks(), checkImages(), getResponseFromAPI().

The report function is called whenever a checkpoint is reached or the result (i.e) PASS, FAIL, ERROR, WARNING or INFO is to be logged. This writes into the HTML extent report.

The checkLinks function is called to perform a Smoke Test to check if all the links in the given web site are in working condition or not. This writes the findings into the HTML extent report.

The checkImages function is called to perform a Smoke Test to check if all the images in the given web site are in working condition or not. This writes the findings into the HTML extent report.

The getResponseFromAPI function is called to perform API Tests and sends back a response from an API depending on various parameters like Method Type, URI, Path Parameters, Query Parameters, Pay load, Headers and Authorization Token. The response received can then be examined to verify the API functionality.

### ExtentManager

This class contains the Instance() function which returns an object of the type ExtentReport. It is used to initially setup the HTML ExtentReport.

### Database Connection

This class contains the Instance() function which returns an object of the type ExtentReport. It is used to initially setup the HTML ExtentReport.